import * as postService from '../services/postService.js';

export const listPosts = async (req, res) => {
  try {
    const posts = await postService.getAllPosts();
    res.json({
      data: posts,
      message: 'Posts fetched successfully'
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const getPostDetail = async (req, res, next) => {
  try {
    const post = await postService.getPostDetails(req.params.id);
    res.json(post);
  } catch (error) {
    next(error);
  }
};

export const updatePostStatus = async (req, res, next) => {
  try {
    const post = await postService.updateStatus(req.params.id, req.body.status);
    res.json(post);
  } catch (error) {
    next(error);
  }
};

export const createPost = async (req, res) => {
  try {
    // ✅ Check if user is authenticated
    if (!req.user || !req.user.userId) {
      return res.status(401).json({ error: 'User not authenticated' });
    }

    const { type } = req.body;
    let result;
    if (type === 'liveLocation') {
      result = await postService.createLiveLocation(req.user.userId, req.body);
    } else {
      const { stops, ...postData } = req.body;
      result = await postService.createRoutePost(req.user.userId, postData, stops);
    }

    res.status(201).json(result);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const updateStatus = async (req, res) => {
  try {
    const post = await postService.updateStatus(req.params.id, req.body.status);
    res.json(post);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const deletePost = async (req, res) => {
  try {
    await postService.removePost(req.params.id);
    res.json({ message: 'Post supprimé avec succès' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// ✅ FIXED: Validate user before voting
export const upvote = async (req, res, next) => {
  try {
    // ✅ Check if user is authenticated
    if (!req.user || !req.user.userId) {
      return res.status(401).json({ error: 'User not authenticated. Please login.' });
    }

    console.log('✅ Upvoting post:', req.params.id, 'by user:', req.user.userId);
    const post = await postService.upvotePost(req.params.id, req.user.userId);
    res.json(post);
  } catch (error) {
    console.error('❌ Upvote error:', error.message);
    res.status(400).json({ error: error.message });
  }
};

// ✅ FIXED: Validate user before voting
export const downvote = async (req, res, next) => {
  try {
    // ✅ Check if user is authenticated
    if (!req.user || !req.user.userId) {
      return res.status(401).json({ error: 'User not authenticated. Please login.' });
    }

    console.log('✅ Downvoting post:', req.params.id, 'by user:', req.user.userId);
    const post = await postService.downvotePost(req.params.id, req.user.userId);
    res.json(post);
  } catch (error) {
    console.error('❌ Downvote error:', error.message);
    res.status(400).json({ error: error.message });
  }
};